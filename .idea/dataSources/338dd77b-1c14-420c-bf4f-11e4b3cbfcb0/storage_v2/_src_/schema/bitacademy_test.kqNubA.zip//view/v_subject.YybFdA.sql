create view v_subject as
  select
    `sis`.`SubInStep_no` AS `SubInStep_no`,
    `sis`.`Step_no`      AS `Step_no`,
    `sis`.`Subject_no`   AS `Subject_no`,
    `s`.`SubjectName`    AS `SubjectName`
  from `bitacademy_test`.`SubInStep` `sis`
    join `bitacademy_test`.`Subject` `s`
  where (`sis`.`Subject_no` = `s`.`Subject_no`);

